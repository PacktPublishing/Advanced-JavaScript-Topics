//import { yellName, formatName } from './utilities.js';
import emphasizeName from './utilities.js';
//import './alert.js';

//console.log(punct);
console.log(this);
console.log('This is app.js.');

//let name = formatName('Hancock, Steven');

console.log(emphasizeName('Steven Hancock'));