//Create a function that will take the array and a student id (any number you want) as parameters. Use map to create a new array that stores each score in an object that includes the activity ID (first score is 0, second score 1, etc.) as well as the student ID. 

//Create a function that will create a new array with the lowest score removed. (For this exercise if both 0s are removed that is OK.)

//Create a function that will Sum the scores.

//Create a function that will compute the average from an array passed in.

//Create a function that will create a new array of score objects that have a 0 score.

//Using the functions you have created, generate a new array with full data. Compute the average once the lowest score has been removed. And create an array of zero scores with the full data that could be provided to the learner.

const array = [10, 0, 90, 80, 50, 0, 60];




