
var obj = {
    firstName: "Steven",
    lastName: "Smith",
    startDate: "January 10, 2015",
    type: "admin"
};