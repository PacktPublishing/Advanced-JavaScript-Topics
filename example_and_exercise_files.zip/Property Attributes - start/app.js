var  obj = {
    type: "rectangle",
    width: 10,
    height: 5
};