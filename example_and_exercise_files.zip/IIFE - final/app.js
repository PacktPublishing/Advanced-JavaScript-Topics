


//Function Expression
(function(num) {
    console.log(num * num);
})(4);


