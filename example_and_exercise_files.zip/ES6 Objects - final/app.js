
var obj = {
    start: 0
};

var obj1 = {
    a: 5
};

var obj2 = {
    b: 10
};

var obj3 = {
    c: 15
};

Object.assign(obj, obj1, obj2, obj3);