
var Users = function(fName, lName) {
    this.firstName = fName;
    this.lastName = lName;
};

var user1 = Users("Sam", "Smith");

var user2 = new Users("Tom", "Smith");