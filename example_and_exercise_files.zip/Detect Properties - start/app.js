var  person1 = {
    firstName: "Steven",
    lastName: "Hancock",
    email: "shancock@allthingsjavascript.com",
    type: "admin",
    active: true,
    address: {
        street: "100 N. Main",
        zip: 10001
    }
};
