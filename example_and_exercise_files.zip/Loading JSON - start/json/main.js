var MAINAPP = (function(app) {
    
    return app;
})(MAINAPP || {});