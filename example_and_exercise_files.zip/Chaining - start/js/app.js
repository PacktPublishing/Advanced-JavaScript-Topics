
let str = "The course starts in October, 2018. ";

let str1 = str.replace("2018","2019").toUpperCase().trim();
