"use strict";

var name = "global";

var fun = function() {
    var name = "fun";
    console.log(this);
    console.log(this.name);
};