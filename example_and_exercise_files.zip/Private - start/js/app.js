
var Greeting = function(term) {

    this.greeting = term;
};

var obj1 = new Greeting("Hello");

