//Immediately invoke all three functions.
//Create a function that adds two numbers and assign it to a variable


//Create a function that multiplies the previous number by itself and store it in a second variable.


//Create a function that prints to the console the variable that contains the results of the previous function.