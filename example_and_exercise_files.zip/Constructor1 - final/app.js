var Greeting = function() {

};

var greet1 = new Greeting();

var greet2 = new Greeting();